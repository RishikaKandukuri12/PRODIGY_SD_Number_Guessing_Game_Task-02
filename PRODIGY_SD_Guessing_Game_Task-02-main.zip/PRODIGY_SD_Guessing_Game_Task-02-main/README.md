# PRODIGY_SD_Guessing_Game_Task-02
The aim is to create a Java Programm in which a user is given K chances to estimate a randomly generated number. The game's rules are as follows: If the guessed number is more than the real number, the program will display the message "guessed number greater than the actual number.
